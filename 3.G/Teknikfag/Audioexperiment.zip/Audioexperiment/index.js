function setup(){
    frameRate(60)
    createCanvas(windowWidth, windowHeight)
    background('pink')
}

function draw(){
    //mouseX mouseY frameCount map
}



let mySound;
function preload() {
    soundFormats('mp3', 'ogg');
    mySound = loadSound('./assets/bongo.mp3');
}

function setup() {
}


function mousePressed(){
    mySound.play();
    
}