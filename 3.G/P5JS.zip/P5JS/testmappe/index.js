function setup(){
    console.log('hey')
}

function mousePressed(event) {
    //console.log(event);
    console.log(event.x, event.y)
  }