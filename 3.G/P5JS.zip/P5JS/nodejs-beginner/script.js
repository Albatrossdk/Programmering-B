console.log('jeg er et javascript')
